/*
 * ESP-12E Barrier Control v1.2
 * SPIFFS + WebSocket (Real-time) + Safety Interlock + Auto-Close
 *
 * AP Mode:
 *   SSID     : esp12-barrier
 *   Password : 12345678
 *   Web UI   : http://192.168.4.1
 *   WebSocket: ws://192.168.4.1:81
 *
 * Pins (قابل تغییر با #define):
 *   GPIO5  → Open barrier   (momentary pulse)
 *   GPIO4  → Close barrier  (momentary pulse)
 *   GPIO16 → Sensor RCWL-0516  (obstacle + optional action)
 *   GPIO14 → Sensor LD2410B    (obstacle + optional close)
 *   GPIO12 → Sensor RCWL-0516  (obstacle + optional open)
 *
 * Logic:
 *   - Any sensor HIGH = obstacle → block ALL close commands
 *   - Previous functionality kept (toggles enable sensor→action)
 *   - Auto-close: after open + sensors clear → wait X seconds → close
 *   - Auto-close delay & enable from UI
 *
 * Libraries: ArduinoJson + WebSockets (by Links2004)
 */

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <FS.h>
#include <ArduinoJson.h>
#include <WebSocketsServer.h>

// ================== AP ==================
const char* ap_ssid     = "esp12-barrier";
const char* ap_password = "12345678";

// ================== Pins ==================
#define PIN_OPEN      5
#define PIN_CLOSE     4
#define PIN_SENSOR16  16
#define PIN_SENSOR14  14
#define PIN_SENSOR12  12

#define PULSE_MS      100

// ================== Objects ==================
ESP8266WebServer server(80);
WebSocketsServer webSocket(81);

// ================== Sensor States ==================
bool s16 = false, s14 = false, s12 = false;
bool lastS16 = false, lastS14 = false, lastS12 = false;

// Enable previous actions
bool en16 = false;
bool en14 = false;   // sensor14 → close
bool en12 = false;   // sensor12 → open

// Output states
bool pin4State = false;
bool pin5State = false;

// Pulse control
bool pulsing4 = false, pulsing5 = false;
unsigned long pulse4Start = 0, pulse5Start = 0;

// ================== Barrier & Safety ==================
bool barrierOpen    = false;
bool obstacle       = false;
bool autoCloseEn    = false;
uint16_t autoCloseSec = 10;
bool waitingClear   = false;
unsigned long clearTime = 0;
bool autoCloseArmed = false;

// ================== Helpers ==================
String getContentType(String filename) {
  if (filename.endsWith(".html")) return "text/html";
  if (filename.endsWith(".css"))  return "text/css";
  if (filename.endsWith(".js"))   return "application/javascript";
  if (filename.endsWith(".json")) return "application/json";
  return "text/plain";
}

bool handleFileRead(String path) {
  if (path.endsWith("/")) path += "index.html";
  if (SPIFFS.exists(path)) {
    File f = SPIFFS.open(path, "r");
    server.streamFile(f, getContentType(path));
    f.close();
    return true;
  }
  return false;
}

void broadcastState() {
  StaticJsonDocument<320> doc;
  doc["s16"]    = s16;
  doc["s14"]    = s14;
  doc["s12"]    = s12;
  doc["e16"]    = en16;
  doc["e14"]    = en14;
  doc["e12"]    = en12;
  doc["p4"]     = pin4State;
  doc["p5"]     = pin5State;
  doc["open"]   = barrierOpen;
  doc["obst"]   = obstacle;
  doc["autoEn"] = autoCloseEn;
  doc["autoSec"]= autoCloseSec;
  doc["armed"]  = autoCloseArmed;

  String json;
  serializeJson(doc, json);
  webSocket.broadcastTXT(json);
}

// ================== Actions ==================
void doOpen() {
  digitalWrite(PIN_OPEN, HIGH);
  pin5State = true;
  pulsing5 = true;
  pulse5Start = millis();
  barrierOpen = true;
  waitingClear = true;
  autoCloseArmed = false;
  Serial.println(">> OPEN");
  broadcastState();
}

void doClose() {
  if (obstacle) {
    Serial.println("!! CLOSE blocked (obstacle)");
    broadcastState();
    return;
  }
  digitalWrite(PIN_CLOSE, HIGH);
  pin4State = true;
  pulsing4 = true;
  pulse4Start = millis();
  barrierOpen = false;
  waitingClear = false;
  autoCloseArmed = false;
  Serial.println(">> CLOSE");
  broadcastState();
}

// ================== WebSocket ==================
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  if (type == WStype_CONNECTED) {
    broadcastState();
    return;
  }
  if (type != WStype_TEXT) return;

  StaticJsonDocument<192> doc;
  if (deserializeJson(doc, payload, length)) return;

  const char* cmd = doc["cmd"];
  if (!cmd) return;

  if (strcmp(cmd, "enable") == 0) {
    int pin = doc["pin"];
    bool st = doc["state"];
    if (pin == 16) en16 = st;
    else if (pin == 14) en14 = st;
    else if (pin == 12) en12 = st;
    broadcastState();
  }
  else if (strcmp(cmd, "control") == 0) {
    int pin = doc["pin"];
    bool st = doc["state"];
    if (pin == 5) {
      if (st) doOpen();
      else {
        digitalWrite(PIN_OPEN, LOW);
        pin5State = false;
        pulsing5 = false;
        broadcastState();
      }
    }
    else if (pin == 4) {
      if (st) doClose();
      else {
        digitalWrite(PIN_CLOSE, LOW);
        pin4State = false;
        pulsing4 = false;
        broadcastState();
      }
    }
  }
  else if (strcmp(cmd, "auto") == 0) {
    if (doc.containsKey("en"))  autoCloseEn = doc["en"];
    if (doc.containsKey("sec")) {
      int s = doc["sec"];
      if (s < 1) s = 1;
      if (s > 600) s = 600;
      autoCloseSec = s;
    }
    if (!autoCloseEn) {
      autoCloseArmed = false;
      waitingClear = false;
    }
    broadcastState();
  }
}

// ================== HTTP ==================
void handleNotFound() {
  if (!handleFileRead(server.uri()))
    server.send(404, "text/plain", "Not Found");
}

// ================== Setup ==================
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\n=== ESP-12E Barrier v1.2 ===");

  pinMode(PIN_OPEN, OUTPUT);
  pinMode(PIN_CLOSE, OUTPUT);
  pinMode(PIN_SENSOR16, INPUT);
  pinMode(PIN_SENSOR14, INPUT);
  pinMode(PIN_SENSOR12, INPUT);
  digitalWrite(PIN_OPEN, LOW);
  digitalWrite(PIN_CLOSE, LOW);

  if (!SPIFFS.begin()) {
    Serial.println("SPIFFS FAIL");
    return;
  }

  WiFi.mode(WIFI_AP);
  WiFi.softAP(ap_ssid, ap_password);
  Serial.printf("AP: %s / %s\n", ap_ssid, ap_password);
  Serial.println(WiFi.softAPIP());

  server.onNotFound(handleNotFound);
  server.begin();

  webSocket.begin();
  webSocket.onEvent(webSocketEvent);

  Serial.println("Ready → http://192.168.4.1");
}

// ================== Loop ==================
void loop() {
  server.handleClient();
  webSocket.loop();

  // Read sensors
  s16 = digitalRead(PIN_SENSOR16);
  s14 = digitalRead(PIN_SENSOR14);
  s12 = digitalRead(PIN_SENSOR12);

  bool prevObst = obstacle;
  obstacle = s16 || s14 || s12;

  bool changed = (s16 != lastS16) || (s14 != lastS14) || (s12 != lastS12) || (obstacle != prevObst);

  // Previous sensor actions (rising edge)
  if (en14 && s14 && !lastS14) {
    doClose();
  }
  if (en12 && s12 && !lastS12) {
    doOpen();
  }

  // End pulses
  if (pulsing4 && (millis() - pulse4Start >= PULSE_MS)) {
    digitalWrite(PIN_CLOSE, LOW);
    pin4State = false;
    pulsing4 = false;
    changed = true;
  }
  if (pulsing5 && (millis() - pulse5Start >= PULSE_MS)) {
    digitalWrite(PIN_OPEN, LOW);
    pin5State = false;
    pulsing5 = false;
    changed = true;
  }

  // Auto-Close Logic
  if (barrierOpen && autoCloseEn) {
    if (waitingClear) {
      if (!obstacle) {
        waitingClear = false;
        clearTime = millis();
        autoCloseArmed = true;
        Serial.println("Sensors clear → timer started");
        changed = true;
      }
    }
    else if (autoCloseArmed) {
      if (millis() - clearTime >= (unsigned long)autoCloseSec * 1000UL) {
        Serial.println("Timer expired → CLOSE attempt");
        doClose();
        if (barrierOpen) {          // was blocked, retry later
          clearTime = millis();
        }
      }
    }
  }

  lastS16 = s16;
  lastS14 = s14;
  lastS12 = s12;

  if (changed) broadcastState();
  yield();
}
