// ===== ESP-12E Barrier v1.2 - WebSocket =====

let ws = null;
let reconnectTimer = null;

function setConnectionStatus(ok) {
  const badge = document.getElementById('connectionBadge');
  const text = document.getElementById('connText');
  if (ok) {
    badge.classList.add('connected');
    text.textContent = 'متصل';
  } else {
    badge.classList.remove('connected');
    text.textContent = 'قطع ارتباط';
  }
}

function updateUI(d) {
  // LEDs
  document.getElementById('led16').className = d.s16 ? 'led on' : 'led';
  document.getElementById('led14').className = d.s14 ? 'led on' : 'led';
  document.getElementById('led12').className = d.s12 ? 'led on' : 'led';

  // Toggles
  ['16','14','12'].forEach(p => {
    const el = document.getElementById('en' + p);
    if (document.activeElement !== el) el.checked = !!d['e' + p];
  });

  // Pin status
  const s4 = document.getElementById('status4');
  const s5 = document.getElementById('status5');
  s4.textContent = d.p4 ? 'روشن ●' : 'خاموش';
  s4.className = d.p4 ? 'control-status on' : 'control-status';
  s5.textContent = d.p5 ? 'روشن ●' : 'خاموش';
  s5.className = d.p5 ? 'control-status on' : 'control-status';

  // Barrier
  const bState = document.getElementById('barrierState');
  if (d.open) {
    bState.textContent = 'باز';
    bState.className = 'value open';
  } else {
    bState.textContent = 'بسته';
    bState.className = 'value closed';
  }

  // Obstacle
  const oState = document.getElementById('obstacleState');
  if (d.obst) {
    oState.textContent = 'وجود دارد';
    oState.className = 'value danger';
  } else {
    oState.textContent = 'آزاد';
    oState.className = 'value ok';
  }

  // Timer
  const tState = document.getElementById('timerState');
  if (!d.autoEn) {
    tState.textContent = 'غیرفعال';
    tState.className = 'value closed';
  } else if (d.armed) {
    tState.textContent = 'در حال شمارش';
    tState.className = 'value armed';
  } else if (d.open) {
    tState.textContent = 'منتظر خالی شدن';
    tState.className = 'value armed';
  } else {
    tState.textContent = 'آماده';
    tState.className = 'value ok';
  }

  // Auto settings
  const autoEn = document.getElementById('autoEn');
  if (document.activeElement !== autoEn) autoEn.checked = !!d.autoEn;

  const autoSec = document.getElementById('autoSec');
  if (document.activeElement !== autoSec) autoSec.value = d.autoSec || 10;
}

function sendWS(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(obj));
  }
}

function pressPin(pin) {
  sendWS({ cmd: 'control', pin: pin, state: 1 });
  const btn = document.getElementById('btn' + pin);
  if (btn) btn.classList.add('pressed');
}
function releasePin(pin) {
  sendWS({ cmd: 'control', pin: pin, state: 0 });
  const btn = document.getElementById('btn' + pin);
  if (btn) btn.classList.remove('pressed');
}

function setupToggles() {
  ['16','14','12'].forEach(p => {
    document.getElementById('en' + p).addEventListener('change', function() {
      sendWS({ cmd: 'enable', pin: parseInt(p), state: this.checked ? 1 : 0 });
    });
  });
  document.getElementById('autoEn').addEventListener('change', function() {
    sendWS({ cmd: 'auto', en: this.checked });
  });
}

function saveAuto() {
  const sec = parseInt(document.getElementById('autoSec').value) || 10;
  sendWS({ cmd: 'auto', sec: sec });
}

function connect() {
  const host = location.hostname || '192.168.4.1';
  ws = new WebSocket('ws://' + host + ':81');
  ws.onopen = () => {
    setConnectionStatus(true);
    if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  };
  ws.onclose = () => {
    setConnectionStatus(false);
    reconnectTimer = setTimeout(connect, 2000);
  };
  ws.onerror = () => ws.close();
  ws.onmessage = (e) => {
    try { updateUI(JSON.parse(e.data)); } catch(err) {}
  };
}

document.addEventListener('contextmenu', e => e.preventDefault());
setupToggles();
connect();
